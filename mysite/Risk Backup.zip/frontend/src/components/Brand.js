import React from 'react'

const Brand = () => {

    const divStyle = {
        backgroundColor: '#2f3343', // set your desired background color here
        height: '100%',
        color: 'white'
        };  

    return (
        <div style={divStyle}><b>Risk Meter</b></div>
    )
    }

export default Brand